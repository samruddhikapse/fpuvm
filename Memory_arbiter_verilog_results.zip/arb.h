`define IDLE       3'b001
  `define GRANT_TDSP 3'b000
  `define GRANT_DMA  3'b010
  `define CLEAR      3'b011
  `define DMA_PRI    3'b111